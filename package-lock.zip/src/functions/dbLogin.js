const mongoose = require("mongoose");
const fs = require('fs');
const path = require('path');

module.exports = (client) => {
    client.dbLogin = async () => {
        const mongoEventFiles = fs.readdirSync(path.join(__dirname, '..', 'mongoEvents')).filter(file => file.endsWith(".js"));
        
        for (const file of mongoEventFiles) {
            const event = require(`../mongoEvents/${file}`);
            if (event.once) {
                mongoose.connection.once(event.name, (...args) => event.execute(...args));
            } else {
                mongoose.connection.on(event.name, (...args) => event.execute(...args));
            }
        }

        mongoose.Promise = global.Promise;
        
        mongoose.connect(process.env.MONGODB_SRV)
            .then(() => {
                console.log('Connected to MongoDB');
            })
            .catch((err) => {
                console.error('MongoDB connection error:', err);
            });
    };
}