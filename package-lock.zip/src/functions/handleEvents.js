const fs = require('node:fs');
const path = require('node:path');

module.exports = (client) => {
    client.handleEvents = async (eventFiles, pathToEvents) => {
        for (const file of eventFiles) {
            const filePath = path.join(pathToEvents, file);
            const event = require(filePath);
            
            if (event.once) {
                client.once(event.name, (...args) => event.execute(...args, client));
            } else {
                client.on(event.name, (...args) => event.execute(...args, client));
            }
        }
        console.log(`Loaded ${eventFiles.length} events`);
    }
}