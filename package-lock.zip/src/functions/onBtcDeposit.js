const { MessageEmbed } = require('discord.js');
const axios = require('axios');
const profile = require('../schemas/profile')

module.exports = (client) => {
    client.onBtcDeposit = async (reqBody) => {
        try {
            // Fetch userId from input_address
            let addressData = await client.getAddress(undefined, reqBody.input_address);
            if (!addressData?.userId) {
                console.error(`No user found for address: ${reqBody.input_address}`);
                return;
            }
            const userId = addressData.userId;
            const user = await client.users.fetch(userId);

            // Fetch user's profile (including permanent BTC address)
            const userProfile = await profile.findOne({ userId });
            const permanentAddress = userProfile?.btcAddress || "No address set";

            setTimeout(async () => {
                let txInfo;
                try {
                    const res = await axios.get(`https://mempool.space/tx/${reqBody.input_transaction_hash}`);
                    txInfo = res.data;
                } catch (err) {
                    console.error(`Error fetching transaction info: ${err}`);
                    return;
                }

                let btcPrice;
                try {
                    const res = await axios.get(`https://min-api.cryptocompare.com/data/price?fsym=BTC&tsyms=USD`);
                    btcPrice = res.data.USD;
                } catch (err) {
                    console.error(`Error fetching BTC price: ${err}`);
                    return;
                }

                const usdAmtFee = (txInfo.fee / 100000000) * btcPrice;
                const usdAmt = (reqBody.value / 100000000) * btcPrice;

                const txDate = new Date().toLocaleString();

                // PENDING DEPOSIT
                if (reqBody.confirmations === 0) {
                    const pendingEmbed = new MessageEmbed()
                        .setTitle(`Pending Bitcoin Deposit`)
                        .setDescription(`> When this transaction reaches **1** confirmation, <@${userId}> will be directly messaged.`)
                        .addFields(
                            { name: `Transaction Hash`, value: `[${reqBody.input_transaction_hash}](https://mempool.space/tx/${reqBody.input_transaction_hash})`, inline: false },
                            { name: `Total Amount`, value: `$${usdAmt.toFixed(2)} USD`, inline: true },
                            { name: `Confirmations`, value: `0/1`, inline: true },
                            { name: `ETA`, value: `~10m`, inline: true },
                            { name: `Fee`, value: `$${usdAmtFee.toFixed(2)} USD`, inline: true },
                            { name: `Time seen`, value: `${txDate}`, inline: true },
                            { name: `Permanent Address`, value: `<:btc:emoji_id> ${permanentAddress}`, inline: true }
                        )
                        .setColor('#00ffff');

                    await user.send({ embeds: [pendingEmbed] });
                    await client.channels.cache.get(process.env.DEPOSIT_LOG_CHANNEL_ID).send({ embeds: [pendingEmbed] });

                // CONFIRMED DEPOSIT
                } else if (reqBody.confirmations === 1) {
                    await profile.findOneAndUpdate(
                        { userId },
                        { $inc: { balance: +usdAmt, totalDeposited: +usdAmt } }
                    );

                    const updatedProfile = await profile.findOne({ userId });

                    const confirmedEmbed = new MessageEmbed()
                        .setTitle(`Bitcoin Deposit Confirmed`)
                        .setDescription(`> <@${userId}>, this [transaction](https://mempool.space/tx/${reqBody.input_transaction_hash}) has reached **1** confirmation.`)
                        .addFields(
                            { name: `Amount Deposited`, value: `$${usdAmt.toFixed(2)} USD`, inline: true },
                            { name: `New Balance`, value: `$${updatedProfile.balance.toFixed(2)} USD`, inline: true },
                            { name: `Permanent Address`, value: `<:btc:emoji_id> ${permanentAddress}`, inline: true }
                        )
                        .setFooter('If you would like to deposit more, just send more to your permanent address')
                        .setColor('#00ff00');

                    await user.send({ embeds: [confirmedEmbed] });
                    await client.channels.cache.get(process.env.DEPOSIT_LOG_CHANNEL_ID).send({ embeds: [confirmedEmbed] });
                }
            }, 10000);

        } catch (err) {
            console.error(`Error in onBtcDeposit: ${err}`);
        }
    };
};