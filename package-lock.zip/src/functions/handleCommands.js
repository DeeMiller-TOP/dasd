const { REST } = require('@discordjs/rest');
const { Routes } = require('discord-api-types/v10');
const fs = require('node:fs');
const path = require('node:path');

const clientId = process.env.BOT_ID;
const guildId = process.env.GUILD_ID;

module.exports = (client) => {
    client.handleCommands = async (commandFolders, pathToCommands) => {
        client.commandArray = [];
        
        for (const folder of commandFolders) {
            const commandsPath = path.join(pathToCommands, folder);
            const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

            for (const file of commandFiles) {
                const filePath = path.join(commandsPath, file);
                const command = require(filePath);
                
                // Set a new item in the Collection with the key as the command name
                if ('data' in command && 'execute' in command) {
                    client.commands.set(command.data.name, command);
                    client.commandArray.push(command.data.toJSON());
                } else {
                    console.log(`[WARNING] The command at ${filePath} is missing a required "data" or "execute" property.`);
                }
            }
        }

        const rest = new REST({ version: '10' }).setToken(process.env.BOT_TOKEN);

        (async () => {
            try {
                console.log('Started refreshing application (/) commands.');

                if (guildId) {
                    // Register commands for a specific guild (faster for development)
                    await rest.put(
                        Routes.applicationGuildCommands(clientId, guildId),
                        { body: client.commandArray }
                    );
                } else {
                    // Register global commands (takes up to an hour to update)
                    await rest.put(
                        Routes.applicationCommands(clientId),
                        { body: client.commandArray }
                    );
                }

                console.log('Successfully reloaded application (/) commands.');
            } catch (error) {
                console.error('Error registering commands:', error);
            }
        })();
    }
}