const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const profile = require('../../schemas/profile');

const rndOrgApi = require('../../rndOrg');
const dice = require('../../schemas/dice');

const rnd = new rndOrgApi.randomOrg(process.env.API_KEY);
rnd.setAuth(process.env.RND_USER, process.env.RND_PASS);

module.exports = {
	data: new SlashCommandBuilder()
		.setName('dice')
		.setDescription('Multiply your money in a provably fair way (RTP: 95%)')
        .addNumberOption(option =>
            option
                .setName('multiplier')
                .setDescription('Choose a multiplier (min: 1.02 max: 1000)')
                .setRequired(true))
		.addNumberOption(option =>
			option
				.setName('amount')
				.setDescription('Bet amount')
				.setRequired(true)),

    async execute(interaction, client) {

        await interaction.deferReply();

		const interactorProfile = await client.getProfile(interaction.user.id);

        const rtp = 95;

		let amount = interaction.options.getNumber('amount');
		amount = Number(amount.toFixed(2));

        let multiplier = interaction.options.getNumber('multiplier');
        multiplier = Number(multiplier.toFixed(2));

        let winChance = rtp / multiplier;
        winChance = Number(winChance.toFixed(2));

        let winAmt = (amount * multiplier) - amount;
		if(winAmt > 20){ winAmt = 20; }

        // ================= ERROR CHECKS =================

		if(interactorProfile.activeGame)
            return interaction.editReply({
                embeds: [
                    new EmbedBuilder()
                        .setTitle("🚫 Error")
                        .setDescription(`> <@${interaction.user.id}>, you have an active game!`)
                        .setFooter({ text: "Please wait for that game to end" })
                        .setColor(0xbe1932)
                ]
            });

		if(interactorProfile.activeWithdraw)
            return interaction.editReply({
                embeds: [
                    new EmbedBuilder()
                        .setTitle("🚫 Error")
                        .setDescription(`> <@${interaction.user.id}>, you have an active withdraw!`)
                        .setFooter({ text: "Please wait for that withdraw to finish" })
                        .setColor(0xbe1932)
                ]
            });

		if(amount < .02)
            return interaction.editReply({
                embeds: [
                    new EmbedBuilder()
                        .setTitle("🚫 Error")
                        .setDescription(`> <@${interaction.user.id}>, you can't bet less than $0.02!`)
                        .setFooter({ text: "Make sure your bet is above $0.02" })
                        .setColor(0xbe1932)
                ]
            });

		if(interactorProfile.balance < amount)
            return interaction.editReply({
                embeds: [
                    new EmbedBuilder()
                        .setTitle("🚫 Error")
                        .setDescription(`> <@${interaction.user.id}>, you don't have enough balance!`)
                        .setFooter({ text: "Use /balance to check your balance" })
                        .setColor(0xbe1932)
                ]
            });

        if(multiplier < 1.02)
            return interaction.editReply({
                embeds: [
                    new EmbedBuilder()
                        .setTitle("🚫 Error")
                        .setDescription(`> <@${interaction.user.id}>, multiplier must be at least 1.02`)
                        .setColor(0xbe1932)
                ]
            });

        if(multiplier > 1000)
            return interaction.editReply({
                embeds: [
                    new EmbedBuilder()
                        .setTitle("🚫 Error")
                        .setDescription(`> <@${interaction.user.id}>, multiplier can't exceed 1000`)
                        .setColor(0xbe1932)
                ]
            });

		await profile.findOneAndUpdate(
            { userId: interaction.user.id },
            { $set: { activeGame: true } }
        );

        // ================= PENDING EMBED =================

        const pendingDiceEmbed = new EmbedBuilder()
            .addFields(
                {
                    name: `🎲 Dice Info`,
                    value:
`> 💵 Bet Amount: **$${amount}**
> 💰 Profit on win: **$${winAmt.toFixed(2)}**
> 🧾 Multiplier: **${multiplier}x**
> 🎯 Roll Under: \`${winChance}\`/100
> 🤞 Win Chance: **${winChance}%**`,
                    inline: true
                },
                {
                    name: `👤 ${interaction.user.username}`,
                    value:
`> 💵 Balance: **$${interactorProfile.balance.toFixed(2)}**
> 🏆 Balance if Win: **$${(interactorProfile.balance + winAmt).toFixed(2)}**
> 💀 Balance if Lose: **$${(interactorProfile.balance - amount).toFixed(2)}**`,
                    inline: true
                }
            )
            .setAuthor({
                name: `${interaction.user.tag} - Pending Dice`,
                iconURL: interaction.user.displayAvatarURL()
            })
            .setFooter({ text: "This game expires in 30 seconds" })
            .setColor(0xff8400);

        const timedOutDiceEmbed = EmbedBuilder.from(pendingDiceEmbed)
            .setAuthor({
                name: `${interaction.user.tag} - Timed Out Dice`,
                iconURL: interaction.user.displayAvatarURL()
            })
            .setFooter({ text: "This game expired" })
            .setColor(0xbe1932);

        const declinedDiceEmbed = EmbedBuilder.from(pendingDiceEmbed)
            .setAuthor({
                name: `${interaction.user.tag} - Declined Dice`,
                iconURL: interaction.user.displayAvatarURL()
            })
            .setFooter({ text: "This game was declined" })
            .setColor(0xbe1932);

        // ================= BUTTONS =================

		const pendingAcceptButtons = new ActionRowBuilder().addComponents(
			new ButtonBuilder()
				.setCustomId('accepted')
				.setStyle(ButtonStyle.Secondary)
				.setLabel('Accept')
				.setEmoji('✅'),

			new ButtonBuilder()
				.setCustomId('declined')
				.setStyle(ButtonStyle.Secondary)
				.setLabel('Decline')
				.setEmoji('❌')
		);

		const disabledAcceptButtons = new ActionRowBuilder().addComponents(
			new ButtonBuilder()
				.setCustomId('accepted')
				.setStyle(ButtonStyle.Secondary)
				.setLabel('Accept')
				.setDisabled(true)
				.setEmoji('✅'),

			new ButtonBuilder()
				.setCustomId('declined')
				.setStyle(ButtonStyle.Secondary)
				.setLabel('Decline')
				.setDisabled(true)
				.setEmoji('❌')
		);

        const msg = await interaction.editReply({
			content: `<@${interaction.user.id}>`,
			embeds: [pendingDiceEmbed],
			components: [pendingAcceptButtons]
		});

        // ================= COLLECTOR =================

		const collector = msg.createMessageComponentCollector({
            filter: i => i.user.id === interaction.user.id,
            max: 1,
            time: 30000
        });

		let temp;

		collector.on('collect', async (i) => {

			temp = 'collected';

            await i.deferUpdate();

            if(i.customId === 'declined'){

                await msg.edit({
                    embeds: [declinedDiceEmbed],
                    components: [disabledAcceptButtons]
                });

		        await profile.findOneAndUpdate(
                    { userId: interaction.user.id },
                    { $set: { activeGame: false } }
                );

                return;
            }

            // ================= RANDOM ROLL =================

            rnd.generateSignedDecimalFractions(1, 4).then(async (res) => {

                let result = res.result.random.data[0] * 100;

                if(result < winChance){

                    await profile.findOneAndUpdate(
                        { userId: interaction.user.id },
                        {
                            $inc: {
                                balance: winAmt,
                                totalWagered: amount,
                                wins: 1,
                                profit: winAmt,
                                totalGamesPlayed: 1
                            },
                            $set: { activeGame: false }
                        }
                    );

                    const winEmbed = new EmbedBuilder()
                        .setDescription(`**You won** $${winAmt.toFixed(2)} 🏆 | Rolled \`${result.toFixed(2)}\``)
                        .setColor(0x00ff00);

                    await msg.edit({
                        embeds: [winEmbed],
                        components: []
                    });

                } else {

                    await profile.findOneAndUpdate(
                        { userId: interaction.user.id },
                        {
                            $inc: {
                                balance: -amount,
                                totalWagered: amount,
                                loses: 1,
                                profit: -amount,
                                totalGamesPlayed: 1
                            },
                            $set: { activeGame: false }
                        }
                    );

                    const loseEmbed = new EmbedBuilder()
                        .setDescription(`**You lost** $${amount} 💀 | Rolled \`${result.toFixed(2)}\``)
                        .setColor(0xbe1932);

                    await msg.edit({
                        embeds: [loseEmbed],
                        components: []
                    });

                }

            });

        });

        collector.on('end', async () => {

            if(temp) return;

            await msg.edit({
                embeds: [timedOutDiceEmbed],
                components: [disabledAcceptButtons]
            });

		    await profile.findOneAndUpdate(
                { userId: interaction.user.id },
                { $set: { activeGame: false } }
            );

        });

    }
};