const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const shuffleSeed = require('shuffle-seed');
const profile = require('../../schemas/profile.js');
const rndOrgApi = require('../../rndOrg.js');

// Random.org API keys rotation
const randomOrgApiKeys = [
    process.env.API_KEY,
    process.env.API_KEY_2,
    process.env.API_KEY_3,
    process.env.API_KEY_4
].filter(Boolean);

module.exports = {
    data: new SlashCommandBuilder()
        .setName('bj')
        .setDescription('Plays a game of blackjack against the house')
        .addNumberOption(option =>
            option
                .setName('amount')
                .setDescription('The amount of balance you would like to gamble')
                .setRequired(true)),
    async execute(interaction, client) {
        await interaction.deferReply();

        let betAmount = interaction.options.getNumber('amount').toFixed(2);
        const userProfile = await client.getProfile(interaction.user.id);

        // Validation checks
        if (userProfile.activeGame) {
            return interaction.editReply({
                embeds: [{
                    title: "🚫 Error",
                    description: `> <@${interaction.user.id}>, you have an active game!`,
                    color: 0xbe1932,
                    footer: { text: "Please wait for that game to end" }
                }]
            });
        }

        if (userProfile.activeWithdraw) {
            return interaction.editReply({
                embeds: [{
                    title: "🚫 Error",
                    description: `> <@${interaction.user.id}>, you already have an active withdraw!`,
                    color: 0xbe1932,
                    footer: { text: "Please wait for that withdraw to finish" }
                }]
            });
        }

        if (betAmount < 0.5) {
            return interaction.editReply({
                embeds: [{
                    title: "🚫 Error",
                    description: `> <@${interaction.user.id}>, the minimum bet amount is $0.50!`,
                    color: 0xbe1932,
                    footer: { text: "Use the command /balance to check your balance" }
                }]
            });
        }

        if (userProfile.balance < betAmount) {
            return interaction.editReply({
                embeds: [{
                    title: "🚫 Error",
                    description: `> <@${interaction.user.id}>, you don't have enough balance to play this game!`,
                    color: 0xbe1932,
                    footer: { text: "Use the command /balance to check your balance" }
                }]
            });
        }

        if (betAmount > 1000) {
            return interaction.editReply({
                embeds: [{
                    title: "🚫 Error",
                    description: `> <@${interaction.user.id}>, the maximum bet amount is $1000!`,
                    color: 0xbe1932,
                    footer: { text: "Use the command /balance to check your balance" }
                }]
            });
        }

        await profile.findOneAndUpdate({ userId: interaction.user.id }, { $set: { activeGame: true } });

        // Initialize random.org
        const useApiKey = randomOrgApiKeys[Math.floor(Math.random() * randomOrgApiKeys.length)];
        const rnd = new rndOrgApi.randomOrg(useApiKey);
        rnd.setAuth(process.env.RND_USER, process.env.RND_PASS);

        let randomOrgSecretData;
        try {
            randomOrgSecretData = await rnd.generateSignedStrings(1, 32, 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', true);
        } catch (error) {
            console.error('Random.org API error:', error);
            await profile.findOneAndUpdate({ userId: interaction.user.id }, { $set: { activeGame: false } });
            return interaction.editReply({
                embeds: [{
                    title: "🚫 Error",
                    description: `> <@${interaction.user.id}>, could not connect to random.org. Please try again.`,
                    color: 0xbe1932
                }]
            });
        }

        if (!randomOrgSecretData) {
            await profile.findOneAndUpdate({ userId: interaction.user.id }, { $set: { activeGame: false } });
            return interaction.editReply({
                embeds: [{
                    title: "🚫 Error",
                    description: `> <@${interaction.user.id}>, could not generate random seed. Please try again.`,
                    color: 0xbe1932
                }]
            });
        }

        const deckCount = 6;
        const serverSecret = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
        const randomOrgSecret = randomOrgSecretData.result.random.data[0];
        const seed = `${serverSecret}:${randomOrgSecret}`;

        // Generate and shuffle decks
        function generateDecks() {
            const pips = ['♠', '♡', '♣', '♢'];
            const indexes = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
            let cards = [];
            for (let i = 0; i < deckCount; i++) {
                pips.forEach(pip => {
                    indexes.forEach(index => {
                        cards.push({ pip, index });
                    });
                });
            }
            return cards;
        }

        const decks = generateDecks();
        const shoe = shuffleSeed.shuffle(decks, seed);
        const shoeString = shoe.reduce((arr, obj) => {
            arr.push(`${obj.pip}${obj.index}`);
            return arr;
        }, []);

        // Game state
        let cardIndexPlayer = 3;
        let cardIndexDealer = null;
        let didPlayerBlackjack = false;
        let didDealerBlackjack = false;
        let didDealerSneakBlackjack = false;
        let finished = false;
        let dealt = false;
        let temp;
        const blackjackGameId = Math.floor(Math.random() * 100000).toString();

        let playerCardsString = `\`${shoeString[0]}\` \`${shoeString[2]}\``;
        let playerCards = [shoe[0], shoe[2]];
        let dealerCardsString = `\`${shoeString[1]}\` \`?\``;
        let dealerCards = [shoe[1], shoe[3]];

        // Calculate score function
        function calculateScore(cardsIndex) {
            let scoreArr = [0, false];
            for (let i = 0; i < cardsIndex.length; i++) {
                let filteredCard = cardsIndex[i].index;
                if (filteredCard === 'K' || filteredCard === 'Q' || filteredCard === 'J') {
                    scoreArr[0] += 10;
                } else if (filteredCard === 'A') {
                    scoreArr[1] = true;
                    scoreArr[0] += 1;
                } else {
                    scoreArr[0] += Number(filteredCard);
                }
            }
            return scoreArr;
        }

        // Check score function
        function checkScore(cardsIndex, isDealer) {
            let scoreArr = calculateScore(cardsIndex);
            let score = scoreArr[0];
            let returnValue;

            if (scoreArr[1] && score + 10 === 21) {
                returnValue = 'blackjack';
            }
            if (scoreArr[1] && score + 10 > 21) {
                returnValue = 'sub10';
            }
            if (score < 21) {
                returnValue = 'under';
            } else if (score === 21) {
                returnValue = 'blackjack';
            } else if (score > 21) {
                returnValue = 'bust';
            }

            if (isDealer) {
                if (score > 16 && score < 22) {
                    returnValue = 'above';
                }
                if (score < 17) {
                    returnValue = 'hit';
                }
                if (score + 10 > 16 && score + 10 < 22 && scoreArr[1]) {
                    returnValue = 'above';
                }
                if (score + 10 === 21 && scoreArr[1]) {
                    returnValue = 'blackjack';
                }
                if (score === 21) {
                    returnValue = 'blackjack';
                }
            }
            return returnValue;
        }

        let dealerScore = calculateScore(dealerCards);
        let dealerScoreString = '`?`';

        if (dealerCards[0].index === 'A' && (dealerCards[1].index === 'K' || dealerCards[1].index === 'Q' || dealerCards[1].index === 'J' || dealerCards[1].index === '10')) {
            didDealerBlackjack = true;
            dealerScoreString = '`21`';
        } else if (dealerCards[1].index === 'A' && (dealerCards[0].index === 'K' || dealerCards[0].index === 'Q' || dealerCards[0].index === 'J' || dealerCards[0].index === '10')) {
            didDealerSneakBlackjack = true;
        }

        let playerScore = calculateScore(playerCards);
        let playerScoreString = `\`${playerScore[0]}\``;

        if (playerScore[0] + 10 === 21 && playerScore[1]) {
            playerScore[0] += 10;
            playerScoreString = `\`${playerScore[0]}\``;
            didPlayerBlackjack = true;
        } else if (playerScore[1]) {
            playerScoreString = `\`${playerScore[0]} / ${playerScore[0] + 10}\``;
        }

        const startEmbed = new EmbedBuilder()
            .addFields(
                {
                    name: `${interaction.user.username} (Player)`,
                    value: `Cards - ${playerCardsString}\nScore - ${playerScoreString}`,
                    inline: true
                },
                {
                    name: `Dealer`,
                    value: `Cards - ${dealerCardsString}\nScore - ${dealerScoreString}`,
                    inline: true
                }
            )
            .setAuthor({
                name: `${interaction.user.username}'s blackjack game`,
                iconURL: `https://cdn.discordapp.com/avatars/${interaction.user.id}/${interaction.user.avatar}.jpeg`
            })
            .setFooter({ text: 'By playing this game you agree to all TOS rules' })
            .setColor('#26a699');

        const startButtons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('hit')
                    .setStyle(ButtonStyle.Secondary)
                    .setLabel('Hit')
                    .setEmoji('✅'),
                new ButtonBuilder()
                    .setCustomId('stand')
                    .setStyle(ButtonStyle.Secondary)
                    .setLabel('Stand')
                    .setEmoji('❌'),
                new ButtonBuilder()
                    .setCustomId('double')
                    .setStyle(ButtonStyle.Secondary)
                    .setLabel('Double')
                    .setEmoji('💸')
            );

        const disabledButtons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('hit')
                    .setStyle(ButtonStyle.Secondary)
                    .setLabel('Hit')
                    .setEmoji('✅')
                    .setDisabled(true),
                new ButtonBuilder()
                    .setCustomId('stand')
                    .setStyle(ButtonStyle.Secondary)
                    .setLabel('Stand')
                    .setEmoji('❌')
                    .setDisabled(true),
                new ButtonBuilder()
                    .setCustomId('double')
                    .setStyle(ButtonStyle.Secondary)
                    .setLabel('Double')
                    .setEmoji('💸')
                    .setDisabled(true)
            );

        const disabledDoubleButton = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('hit')
                    .setStyle(ButtonStyle.Secondary)
                    .setLabel('Hit')
                    .setEmoji('✅'),
                new ButtonBuilder()
                    .setCustomId('stand')
                    .setStyle(ButtonStyle.Secondary)
                    .setLabel('Stand')
                    .setEmoji('❌'),
                new ButtonBuilder()
                    .setCustomId('double')
                    .setStyle(ButtonStyle.Secondary)
                    .setLabel('Double')
                    .setEmoji('💸')
                    .setDisabled(true)
            );

        const msg = await interaction.editReply({
            embeds: [startEmbed],
            components: [startButtons]
        }).catch(error => {
            console.log('msg deleted');
        });

        if (!msg) {
            await profile.findOneAndUpdate({ userId: interaction.user.id }, { $set: { activeGame: false } });
            return;
        }

        // Handle blackjack outcomes
        if (didPlayerBlackjack && didDealerBlackjack) {
            await push();
        } else if (didPlayerBlackjack && didDealerSneakBlackjack) {
            await push();
        } else if (didPlayerBlackjack && !didDealerBlackjack) {
            await playerWin('blackjack');
        } else if (!didPlayerBlackjack && didDealerBlackjack) {
            await dealerWin('blackjack');
        }

        const filter = async (i) => i.user.id === interaction.user.id;
        const collector = msg.createMessageComponentCollector({ filter, time: 60000 });

        collector.on('collect', async (i) => {
            if (i.customId === 'hit') {
                return await playerHit();
            } else if (i.customId === 'stand') {
                return await playerStand();
            } else if (i.customId === 'double') {
                return await playerDouble();
            }
        });

        collector.on('end', async (collected) => {
            if (temp) return;

            await profile.findOneAndUpdate(
                { userId: interaction.user.id },
                {
                    $inc: { balance: -betAmount, loses: +1, totalGamesPlayed: +1, totalWagered: +betAmount, profit: -betAmount },
                    $set: { activeGame: false }
                }
            );

            const timeoutEmbed = new EmbedBuilder()
                .setDescription('**You didn\'t respond in time.**\nThe dealer is keeping your money.')
                .addFields(
                    {
                        name: `${interaction.user.username} (Player)`,
                        value: `Cards - ${playerCardsString}\nScore - ${playerScoreString}`,
                        inline: true
                    },
                    {
                        name: `Dealer`,
                        value: `Cards - ${dealerCardsString}\nScore - ${dealerScoreString}`,
                        inline: true
                    }
                )
                .setAuthor({
                    name: `${interaction.user.username}'s blackjack game`,
                    iconURL: `https://cdn.discordapp.com/avatars/${interaction.user.id}/${interaction.user.avatar}.jpeg`
                })
                .setFooter({ text: 'If you would like to appeal make a support ticket' })
                .setColor('#ffb300');

            await msg.edit({
                embeds: [timeoutEmbed],
                components: [disabledButtons]
            }).catch(error => {
                console.log('Couldn\'t get message most likely');
            });
        });

        async function playerHit() {
            cardIndexPlayer++;
            playerCards.push(shoe[cardIndexPlayer]);
            playerCardsString += ` \`${shoeString[cardIndexPlayer]}\``;
            playerScore = calculateScore(playerCards);

            if (playerScore[1] && playerScore[0] + 10 < 22) {
                playerScoreString = `\`${playerScore[0]} / ${playerScore[0] + 10}\``;
            } else if (playerScore[0] + 10 === 21 && playerScore[1]) {
                playerScore[0] += 10;
                playerScoreString = `\`${playerScore[0]}\``;
            } else {
                playerScoreString = `\`${playerScore[0]}\``;
            }

            const checkedScore = checkScore(playerCards);
            if (checkedScore === 'sub10') {
                playerScoreString = `\`${playerScore[0]}\``;
                playerScore[1] = false;
            }

            const tempEmbed = new EmbedBuilder()
                .addFields(
                    {
                        name: `${interaction.user.username} (Player)`,
                        value: `Cards - ${playerCardsString}\nScore - ${playerScoreString}`,
                        inline: true
                    },
                    {
                        name: `Dealer`,
                        value: `Cards - ${dealerCardsString}\nScore - ${dealerScoreString}`,
                        inline: true
                    }
                )
                .setAuthor({
                    name: `${interaction.user.username}'s blackjack game`,
                    iconURL: `https://cdn.discordapp.com/avatars/${interaction.user.id}/${interaction.user.avatar}.jpeg`
                })
                .setFooter({ text: 'By playing this game you agree to all TOS rules' })
                .setColor('#26a699');

            await msg.edit({
                embeds: [tempEmbed],
                components: [disabledDoubleButton]
            }).catch(error => {
                console.log('msg deleted');
            });

            if (checkedScore === 'bust') {
                return await playerBust();
            } else if (checkedScore === 'blackjack') {
                return await playerStand();
            }
            return true;
        }

        async function playerStand() {
            await msg.edit({ components: [disabledButtons] }).catch(error => { console.log('msg deleted'); });
            await dealerPlay();
        }

        async function playerDouble() {
            if (betAmount * 2 > userProfile.balance) {
                return interaction.followUp({
                    embeds: [{
                        title: "🚫 Error",
                        description: `> <@${interaction.user.id}>, you don't have enough money to double down!`,
                        color: 0xbe1932,
                        footer: { text: "Use the command /balance to check your balance" }
                    }],
                    ephemeral: true
                });
            }

            betAmount = betAmount * 2;
            const res = await playerHit();
            if (!res) return;
            await playerStand();
        }

        async function playerBust() {
            await msg.edit({ components: [disabledButtons] }).catch(error => { console.log('msg deleted'); });
            await dealerWin('bust');
        }

        async function dealerPlay() {
            dealerCardsString = `\`${shoeString[1]}\` \`${shoeString[3]}\``;
            dealerScore = calculateScore(dealerCards);

            if (dealerScore[1]) {
                dealerScoreString = `\`${dealerScore[0]} / ${dealerScore[0] + 10}\``;
            } else {
                dealerScoreString = `\`${dealerScore[0]}\``;
            }

            let dealerBoolen = false;
            if (dealerScore[0] > 16) {
                dealerBoolen = false;
            } else if (dealerScore[1] && dealerScore[0] + 10 > 16) {
                dealerBoolen = false;
                dealerScoreString = `\`${dealerScore[0] + 10}\``;
            } else if (dealerScore[0] < 17) {
                dealerBoolen = true;
            }

            const tempEmbed = new EmbedBuilder()
                .addFields(
                    {
                        name: `${interaction.user.username} (Player)`,
                        value: `Cards - ${playerCardsString}\nScore - ${playerScoreString}`,
                        inline: true
                    },
                    {
                        name: `Dealer`,
                        value: `Cards - ${dealerCardsString}\nScore - ${dealerScoreString}`,
                        inline: true
                    }
                )
                .setAuthor({
                    name: `${interaction.user.username}'s blackjack game`,
                    iconURL: `https://cdn.discordapp.com/avatars/${interaction.user.id}/${interaction.user.avatar}.jpeg`
                })
                .setFooter({ text: 'By playing this game you agree to all TOS rules' })
                .setColor('#26a699');

            await msg.edit({ embeds: [tempEmbed] }).catch(error => { console.log('msg deleted'); });

            while (dealerBoolen) {
                dealerBoolen = await dealerHit();
            }

            if (!finished) {
                await checkScoreWin();
            }
        }

        async function dealerHit() {
            await new Promise(r => setTimeout(r, 1000));

            if (dealt) {
                cardIndexDealer++;
            } else {
                cardIndexDealer = cardIndexPlayer + 1;
            }
            dealerCards.push(shoe[cardIndexDealer]);
            dealerCardsString += ` \`${shoeString[cardIndexDealer]}\``;
            dealerScore = calculateScore(dealerCards);
            if (dealerCards.length === 3) dealt = true;

            if (dealerScore[1] && dealerScore[0] < 17) {
                dealerScoreString = `\`${dealerScore[0]} / ${dealerScore[0] + 10}\``;
            } else if (dealerScore[0] + 10 === 21 && dealerScore[1]) {
                dealerScore[0] += 10;
                dealerScoreString = `\`${dealerScore[0]}\``;
            } else {
                dealerScoreString = `\`${dealerScore[0]}\``;
            }

            const checkedScore = checkScore(dealerCards, true);
            if (checkedScore === 'sub10') {
                dealerScoreString = `\`${dealerScore[0]}\``;
                dealerScore[1] = false;
            }

            const tempEmbed = new EmbedBuilder()
                .addFields(
                    {
                        name: `${interaction.user.username} (Player)`,
                        value: `Cards - ${playerCardsString}\nScore - ${playerScoreString}`,
                        inline: true
                    },
                    {
                        name: `Dealer`,
                        value: `Cards - ${dealerCardsString}\nScore - ${dealerScoreString}`,
                        inline: true
                    }
                )
                .setAuthor({
                    name: `${interaction.user.username}'s blackjack game`,
                    iconURL: `https://cdn.discordapp.com/avatars/${interaction.user.id}/${interaction.user.avatar}.jpeg`
                })
                .setFooter({ text: 'By playing this game you agree to all TOS rules' })
                .setColor('#26a699');

            await msg.edit({
                embeds: [tempEmbed],
                components: [disabledButtons]
            }).catch(error => { console.log('msg deleted'); });

            if (checkedScore === 'hit') {
                return true;
            } else if (checkedScore === 'bust') {
                await playerWin('bust');
                return false;
            } else if (checkedScore === 'above') {
                return false;
            }
        }

        async function dealerWin(message) {
            finished = true;
            temp = ' ';
            let messageString;

            if (message === 'blackjack') {
                messageString = 'The dealer got blackjack.';
            } else if (message === 'bust') {
                messageString = 'You went over 21 and busted.';
            } else if (message === 'score') {
                messageString = 'The dealer beats you in points.';
            }

            await profile.findOneAndUpdate(
                { userId: interaction.user.id },
                {
                    $inc: { balance: -betAmount, loses: +1, totalGamesPlayed: +1, totalWagered: +betAmount, profit: -betAmount },
                    $set: { activeGame: false }
                }
            );

            const updatedProfile = await client.getProfile(interaction.user.id);

            const dealerWinEmbed = new EmbedBuilder()
                .setDescription(`**You lost. ${messageString}**\nYou lost **$${betAmount}**. You now have **$${updatedProfile.balance.toFixed(2)}**.`)
                .addFields(
                    {
                        name: `${interaction.user.username} (Player)`,
                        value: `Cards - ${playerCardsString}\nScore - ${playerScoreString}`,
                        inline: true
                    },
                    {
                        name: `Dealer`,
                        value: `Cards - ${dealerCardsString}\nScore - ${dealerScoreString}`,
                        inline: true
                    }
                )
                .setAuthor({
                    name: `${interaction.user.username}'s blackjack game`,
                    iconURL: `https://cdn.discordapp.com/avatars/${interaction.user.id}/${interaction.user.avatar}.jpeg`
                })
                .setFooter({ text: `Use the command /bjinfo ${blackjackGameId} to see provably fair` })
                .setColor('#e53835');

            return await msg.edit({
                embeds: [dealerWinEmbed],
                components: [disabledButtons]
            }).catch(error => { console.log('msg deleted'); });
        }

        async function playerWin(message) {
            finished = true;
            temp = ' ';
            let messageString;
            let winAmount = betAmount;

            if (message === 'blackjack') {
                messageString = 'You got blackjack.';
                winAmount = betAmount * 1.5;
            } else if (message === 'bust') {
                messageString = 'The dealer went over 21 and busted.';
            } else if (message === 'score') {
                messageString = 'You beat the dealer in points.';
            }

            if (winAmount > 20) { winAmount = 20; }

            await profile.findOneAndUpdate(
                { userId: interaction.user.id },
                {
                    $inc: { balance: +winAmount, wins: +1, totalGamesPlayed: +1, totalWagered: +betAmount, profit: +betAmount },
                    $set: { activeGame: false }
                }
            );

            const updatedProfile = await client.getProfile(interaction.user.id);

            const playerWinEmbed = new EmbedBuilder()
                .setDescription(`**You won! ${messageString}**\nYou won **$${winAmount.toFixed(2)}**. You now have **$${updatedProfile.balance.toFixed(2)}**.`)
                .addFields(
                    {
                        name: `${interaction.user.username} (Player)`,
                        value: `Cards - ${playerCardsString}\nScore - ${playerScoreString}`,
                        inline: true
                    },
                    {
                        name: `Dealer`,
                        value: `Cards - ${dealerCardsString}\nScore - ${dealerScoreString}`,
                        inline: true
                    }
                )
                .setAuthor({
                    name: `${interaction.user.username}'s blackjack game`,
                    iconURL: `https://cdn.discordapp.com/avatars/${interaction.user.id}/${interaction.user.avatar}.jpeg`
                })
                .setFooter({ text: `Use the command /bjinfo ${blackjackGameId} to see provably fair` })
                .setColor('#4caf4f');

            return await msg.edit({
                embeds: [playerWinEmbed],
                components: [disabledButtons]
            }).catch(error => { console.log('msg deleted'); });
        }

        async function push() {
            temp = ' ';

            await profile.findOneAndUpdate(
                { userId: interaction.user.id },
                {
                    $inc: { totalGamesPlayed: +1, totalWagered: +betAmount },
                    $set: { activeGame: false }
                }
            );

            const updatedProfile = await client.getProfile(interaction.user.id);

            const pushEmbed = new EmbedBuilder()
                .setDescription(`**You pushed. Your score tied with the dealer's score.**\nYou lost **nothing!** You have **$${updatedProfile.balance.toFixed(2)}**.`)
                .addFields(
                    {
                        name: `${interaction.user.username} (Player)`,
                        value: `Cards - ${playerCardsString}\nScore - ${playerScoreString}`,
                        inline: true
                    },
                    {
                        name: `Dealer`,
                        value: `Cards - ${dealerCardsString}\nScore - ${dealerScoreString}`,
                        inline: true
                    }
                )
                .setAuthor({
                    name: `${interaction.user.username}'s blackjack game`,
                    iconURL: `https://cdn.discordapp.com/avatars/${interaction.user.id}/${interaction.user.avatar}.jpeg`
                })
                .setFooter({ text: `Use the command /bjinfo ${blackjackGameId} to see provably fair` })
                .setColor('#ffb300');

            return await msg.edit({
                embeds: [pushEmbed],
                components: [disabledButtons]
            }).catch(error => { console.log('msg deleted'); });
        }

        async function checkScoreWin() {
            let didDealerWin;
            let didPush = false;

            const playerFinalScore = playerScore[1] && playerScore[0] + 10 < 22 ? playerScore[0] + 10 : playerScore[0];
            const dealerFinalScore = dealerScore[1] && dealerScore[0] + 10 < 22 ? dealerScore[0] + 10 : dealerScore[0];

            if (dealerFinalScore > playerFinalScore) {
                didDealerWin = true;
            } else if (dealerFinalScore < playerFinalScore) {
                didDealerWin = false;
            } else {
                didPush = true;
                await push();
            }

            if (didDealerWin && !didPush) {
                await dealerWin('score');
            } else if (!didDealerWin && !didPush) {
                await playerWin('score');
            }
        }

        // Save game to database
        const shoeStringDB = shoe.reduce((arr, obj) => { arr.push(`${obj.pip}${obj.index}`); return arr; }, []).join(', ');
        await client.getBlackjack(
            blackjackGameId,
            betAmount,
            randomOrgSecretData.result.random.hashedApiKey,
            randomOrgSecret,
            serverSecret,
            randomOrgSecretData.result.signature,
            randomOrgSecretData.result.random.completionTime,
            shoeStringDB,
            JSON.stringify(randomOrgSecretData.result.random)
        );
    },
};