const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
data: new SlashCommandBuilder()
.setName('deposit')
.setDescription('Directly messages you on how to deposit crypto')
.addStringOption(option =>
option
.setName('payment')
.setDescription('Choose a deposit option')
.setRequired(true)
.addChoices(
{ name: 'Bitcoin', value: 'btc' },
{ name: 'Litecoin', value: 'ltc' }
)),

async execute(interaction, client) {

try {

await interaction.deferReply({ ephemeral: true });

let emoji;
let cryptoAddy;
let cryptoName;

// Ensure profile exists
await client.getProfile(interaction.user.id);

// Get or create deposit addresses
const addressProfile = await client.getAddress(interaction.user.id);

// Determine selected crypto
const payment = interaction.options.getString('payment');

if (payment === 'btc') {
emoji = process.env.BTC_EMOJI || '₿';
cryptoAddy = addressProfile.btcAddress;
cryptoName = 'Bitcoin';
}

if (payment === 'ltc') {
emoji = process.env.LTC_EMOJI || 'Ł';
cryptoAddy = addressProfile.ltcAddress;
cryptoName = 'Litecoin';
}

// Safety check (prevents undefined)
if (!cryptoAddy) {
throw new Error('Deposit address not generated');
}

// Channel response
const infoEmbed = new EmbedBuilder()
.setTitle('ℹ️ Deposit Information')
.setDescription(`> <@${interaction.user.id}>, your **${cryptoName}** deposit address has been sent to your DMs.`)
.setColor('#6cabfb');

await interaction.editReply({
embeds: [infoEmbed]
});

// DM Embed
const dmEmbed = new EmbedBuilder()
.setTitle(`:coin: ➜ 🏦 ${cryptoName} Deposit`)
.setDescription(
`Deposits require **1 confirmation** to credit your balance.\n\n` +
`**Your permanent address:**\n${emoji} \`${cryptoAddy}\``
)
.setFooter({ text: 'You will be notified when your deposit is detected and confirmed.' })
.setColor('#389cf4')
.setThumbnail(`https://chart.googleapis.com/chart?chs=500x500&cht=qr&chl=${cryptoAddy}`);

// Send DM
await interaction.user.send({
embeds: [dmEmbed]
});

// Send raw address for easy copy
await interaction.user.send({
content: cryptoAddy
});

} catch (err) {

console.error(err);

if (interaction.deferred || interaction.replied) {
await interaction.editReply({
content: '❌ There was an error generating your deposit address.'
});
} else {
await interaction.reply({
content: '❌ There was an error generating your deposit address.',
ephemeral: true
});
}

}

}
};