const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const axios = require('axios');
const profile = require('../../schemas/profile.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('withdraw')
        .setDescription('Withdraws your balance to BTC or LTC')
        .addStringOption(option =>
            option
                .setName('crypto')
                .setDescription('btc or ltc')
                .setRequired(true)
                .addChoices(
                    { name: 'BTC', value: 'btc' },
                    { name: 'LTC', value: 'ltc' }
                ))
        .addNumberOption(option =>
            option
                .setName('amount')
                .setDescription('The amount of balance you would like to withdraw')
                .setRequired(true))
        .addStringOption(option =>
            option
                .setName('address')
                .setDescription('The btc or ltc address you would like to withdraw to')
                .setRequired(true)),
    async execute(interaction, client) {
        await interaction.deferReply();

        const userProfile = await client.getProfile(interaction.user.id);
        let withdrawAmt = interaction.options.getNumber('amount').toFixed(2);

        let crypto, address, blockchain;

        if (interaction.options.getString('crypto') === 'btc') {
            address = 'Btc-Address';
            crypto = 'btc';
            blockchain = 'mempool.space/tx/';
        } else if (interaction.options.getString('crypto') === 'ltc') {
            address = 'Ltc-Address';
            crypto = 'ltc';
            blockchain = 'live.blockcypher.com/ltc/tx/';
        }

        // Validation checks
        if (userProfile.totalWagered < 5) {
            return interaction.editReply({
                embeds: [{
                    title: "🚫 Error",
                    description: `> <@${interaction.user.id}>, you must wager at least $5 to withdraw!`,
                    color: 0xbe1932,
                    footer: { text: "Make sure you wager $5 or more" }
                }]
            });
        }

        if (userProfile.activeGame) {
            return interaction.editReply({
                embeds: [{
                    title: "🚫 Error",
                    description: `> <@${interaction.user.id}>, you have an active game!`,
                    color: 0xbe1932,
                    footer: { text: "Please wait for that game to end" }
                }]
            });
        }

        if (userProfile.activeWithdraw) {
            return interaction.editReply({
                embeds: [{
                    title: "🚫 Error",
                    description: `> <@${interaction.user.id}>, you already have an active withdraw!`,
                    color: 0xbe1932,
                    footer: { text: "Please wait for that withdraw to finish" }
                }]
            });
        }

        if (withdrawAmt < 5) {
            return interaction.editReply({
                embeds: [{
                    title: "🚫 Error",
                    description: `> <@${interaction.user.id}>, you can't withdraw less than $5!`,
                    color: 0xbe1932,
                    footer: { text: "Make sure that your withdraw amount is $5 or above" }
                }]
            });
        }

        if (userProfile.balance < withdrawAmt) {
            return interaction.editReply({
                embeds: [{
                    title: "🚫 Error",
                    description: `> <@${interaction.user.id}>, you can't withdraw balance you don't have!`,
                    color: 0xbe1932,
                    footer: { text: "Use the command /balance to check your balance" }
                }]
            });
        }

        // Channel info embed
        const infoEmbed = new EmbedBuilder()
            .setTitle('ℹ️ Information')
            .setDescription(`> <@${interaction.user.id}>, your withdraw information has been sent via DM.`)
            .setColor('#389cf4');

        await interaction.editReply({
            embeds: [infoEmbed]
        });

        // Pending embed for DM
        const pendingEmbed = new EmbedBuilder()
            .setTitle('⏳ Withdraw Confirmation')
            .setDescription(`<@${interaction.user.id}> please verify your withdraw information, you have 30 seconds.\n\n> ${address}: \`${interaction.options.getString('address')}\`\n> Amount: \`$${withdrawAmt}\`\n\nTo accept or decline hit the correct button below.`)
            .setFooter({ text: 'If this information is incorrect and you do not receive your funds we will not be held responsible' })
            .setColor('#ff8400');

        // Buttons
        const pendingButtons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('accepted')
                    .setStyle(ButtonStyle.Secondary)
                    .setLabel('Confirm Information')
                    .setEmoji('✅'),
                new ButtonBuilder()
                    .setCustomId('declined')
                    .setStyle(ButtonStyle.Secondary)
                    .setLabel('Decline Information')
                    .setEmoji('❌')
            );

        const disabledButtons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('accepted')
                    .setStyle(ButtonStyle.Secondary)
                    .setLabel('Confirm Information')
                    .setEmoji('✅')
                    .setDisabled(true),
                new ButtonBuilder()
                    .setCustomId('declined')
                    .setStyle(ButtonStyle.Secondary)
                    .setLabel('Decline Information')
                    .setEmoji('❌')
                    .setDisabled(true)
            );

        const canceledEmbed = new EmbedBuilder()
            .setTitle('⚠️ Withdraw Canceled')
            .setDescription(`<@${interaction.user.id}> please verify your withdraw information, you have 30 seconds.\n\n> ${address}: \`${interaction.options.getString('address')}\`\n> Amount: \`$${withdrawAmt}\`\n\nTo accept or decline hit the correct button below.`)
            .setFooter({ text: 'This withdraw has been canceled' })
            .setColor('#be1932');

        let msg;
        try {
            msg = await interaction.user.send({
                embeds: [pendingEmbed],
                components: [pendingButtons]
            });
        } catch (error) {
            return console.log('Could not send DM to user');
        }

        // Gives the active withdraw to the user
        await profile.findOneAndUpdate({ userId: interaction.user.id }, { $set: { activeWithdraw: true } });

        // Makes a variable to collect if the user responded in time
        let temp;
        const filter = async (i) => true;
        const collector = msg.createMessageComponentCollector({ filter, max: 1, time: 30000 });

        // When the user clicks a button
        collector.on('collect', async (i) => {
            temp = 'collected';

            if (i.customId == 'accepted') {
                const acceptedEmbed = new EmbedBuilder()
                    .setTitle(':white_check_mark: Withdraw Accepted')
                    .setDescription(`<@${interaction.user.id}>, you have accepted this information to be correct.\n\n> ${address}: \`${interaction.options.getString('address')}\`\n> Amount: \`$${withdrawAmt}\`\n\nTo accept or decline hit the correct button below.`)
                    .setFooter({ text: 'Now processing your withdraw' })
                    .setColor('#00ff00');

                await msg.edit({
                    embeds: [acceptedEmbed],
                    components: [disabledButtons]
                });

                // Gets the crypto price
                let btcPrice, ltcPrice, withdrawAmtSat, withdrawResData;
                
                try {
                    const btcRes = await axios.get(`https://min-api.cryptocompare.com/data/price?fsym=BTC&tsyms=USD`);
                    btcPrice = btcRes.data.USD;
                    
                    const ltcRes = await axios.get(`https://min-api.cryptocompare.com/data/price?fsym=LTC&tsyms=USD`);
                    ltcPrice = ltcRes.data.USD;
                } catch (err) {
                    console.error(err);
                }

                if (crypto == 'btc') {
                    withdrawAmtSat = Number(withdrawAmt) / btcPrice;
                    withdrawAmtSat = Number((withdrawAmtSat * 100000000).toFixed(0));

                    const withdrawData = {
                        "transfer_key": process.env.BTC_APIRONE_TRANSFER_KEY,
                        "destinations": [
                            {
                                "address": interaction.options.getString('address'),
                                "amount": withdrawAmtSat
                            },
                        ],
                        "subtract-fee-from-amount": true
                    };

                    try {
                        const res = await axios.post(`https://apirone.com/api/v2/wallets/${process.env.BTC_APIRONE_WALLET_ID}/transfer`, withdrawData);
                        withdrawResData = res.data;
                    } catch (err) {
                        console.log(err);
                    }

                    if (!withdrawResData) {
                        await profile.findOneAndUpdate({ userId: interaction.user.id }, { $set: { activeWithdraw: false } });
                        return await interaction.user.send({
                            embeds: [{
                                title: "🚫 Error",
                                description: `> <@${interaction.user.id}>, an error has occurred!`,
                                color: 0xbe1932,
                                footer: { text: "Please make sure that your withdraw address is valid" }
                            }]
                        });
                    }
                } else if (crypto == 'ltc') {
                    withdrawAmtSat = Number(withdrawAmt) / ltcPrice;
                    withdrawAmtSat = Number((withdrawAmtSat * 100000000).toFixed(0));

                    const withdrawData = {
                        "transfer_key": process.env.LTC_APIRONE_TRANSFER_KEY,
                        "destinations": [
                            {
                                "address": interaction.options.getString('address'),
                                "amount": withdrawAmtSat
                            },
                        ],
                        "subtract-fee-from-amount": true
                    };

                    try {
                        const res = await axios.post(`https://apirone.com/api/v2/wallets/${process.env.LTC_APIRONE_WALLET_ID}/transfer`, withdrawData);
                        withdrawResData = res.data;
                    } catch (err) {
                        console.log(err);
                    }

                    if (!withdrawResData) {
                        await profile.findOneAndUpdate({ userId: interaction.user.id }, { $set: { activeWithdraw: false } });
                        return await interaction.user.send({
                            embeds: [{
                                title: "🚫 Error",
                                description: `> <@${interaction.user.id}>, an error has occurred!`,
                                color: 0xbe1932,
                                footer: { text: "Please make sure that your withdraw address is valid" }
                            }]
                        });
                    }
                }

                const lastEmbed = new EmbedBuilder()
                    .setTitle('📤 Withdraw Sent')
                    .setDescription(`<@${interaction.user.id}>, your withdraw has been sent.\n\n> ${address}: \`${interaction.options.getString('address')}\`\n> Amount: \`$${withdrawAmt}\`\n\n[${withdrawResData.txs[0]}](https://${blockchain}${withdrawResData.txs[0]})`)
                    .setFooter({ text: 'If there are any errors, please contact support' })
                    .setColor('#00ff00');

                // Removes the active withdraw and takes balance
                await profile.findOneAndUpdate({ userId: interaction.user.id }, { $inc: { balance: -withdrawAmt, totalWithdrawed: +withdrawAmt }, $set: { activeWithdraw: false } });

                await interaction.user.send({
                    embeds: [lastEmbed]
                });
                
                await client.channels.cache.get(process.env.WITHDRAW_LOG_CHANNEL_ID).send({
                    embeds: [lastEmbed]
                });

            } else if (i.customId == 'declined') {
                await profile.findOneAndUpdate({ userId: interaction.user.id }, { $set: { activeWithdraw: false } });

                await msg.edit({
                    embeds: [canceledEmbed],
                    components: [disabledButtons]
                });
            }
        });

        // When time runs out
        collector.on('end', async (collected) => {
            if (temp) return;

            await profile.findOneAndUpdate({ userId: interaction.user.id }, { $set: { activeWithdraw: false } });

            return await msg.edit({
                embeds: [canceledEmbed],
                components: [disabledButtons]
            });
        });
    },
};