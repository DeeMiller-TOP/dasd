// src/commands/misc/deleteprofile.js
const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const Profile = require('../../schemas/profile.js'); // your Mongoose model

module.exports = {
    data: new SlashCommandBuilder()
        .setName('deleteprofile')
        .setDescription('Deletes your user profile permanently.'),

    async execute(interaction, client) {
        await interaction.deferReply({ ephemeral: true });

        try {
            // Find the user's profile
            const userProfile = await Profile.findOne({ userId: interaction.user.id });
            if (!userProfile) {
                return interaction.editReply({
                    content: '⚠️ You do not have a profile to delete.',
                });
            }

            // Delete the profile
            await Profile.deleteOne({ userId: interaction.user.id });

            const embed = new EmbedBuilder()
                .setTitle('✅ Profile Deleted')
                .setDescription(`> <@${interaction.user.id}>, your profile has been successfully deleted.`)
                .setColor('#ff0000')
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });

        } catch (err) {
            console.error('❌ Error deleting profile:', err);
            if (!interaction.replied) {
                await interaction.editReply({
                    content: '❌ An error occurred while deleting your profile.',
                });
            }
        }
    },
};