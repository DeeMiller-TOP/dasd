const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const Profile = require('../../schemas/profile');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('forcewithdraw')
		.setDescription('Forcefully withdraw balance from a user')
		.setDefaultMemberPermissions(PermissionFlagsBits.Administrator)

		.addUserOption(option =>
			option
				.setName('user')
				.setDescription('User to withdraw balance from')
				.setRequired(true))

		.addNumberOption(option =>
			option
				.setName('amount')
				.setDescription('Amount to withdraw')
				.setRequired(true)),

	async execute(interaction) {

		await interaction.deferReply({ ephemeral: true });

		const targetUser = interaction.options.getUser('user');
		let amount = interaction.options.getNumber('amount');

		amount = Number(amount.toFixed(2));

		if (amount <= 0) {
			return interaction.editReply({
				content: '❌ Amount must be greater than 0.'
			});
		}

		const userProfile = await Profile.findOne({ userId: targetUser.id });

		if (!userProfile) {
			return interaction.editReply({
				content: '❌ That user does not have a profile.'
			});
		}

		if (userProfile.balance < amount) {
			return interaction.editReply({
				content: '❌ User does not have enough balance.'
			});
		}

		// Remove balance
		await Profile.findOneAndUpdate(
			{ userId: targetUser.id },
			{
				$inc: {
					balance: -amount,
					totalWithdrawed: amount
				}
			}
		);

		const embed = new EmbedBuilder()
			.setTitle('💸 Force Withdrawal Executed')
			.setColor(0xbe1932)
			.addFields(
				{
					name: '👤 User',
					value: `<@${targetUser.id}>`,
					inline: true
				},
				{
					name: '💰 Amount Withdrawn',
					value: `$${amount.toFixed(2)}`,
					inline: true
				},
				{
					name: '🛠 Executed By',
					value: `<@${interaction.user.id}>`,
					inline: true
				}
			)
			.setTimestamp();

		await interaction.editReply({
			embeds: [embed]
		});

	}
};