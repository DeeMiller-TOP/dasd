const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const Profile = require('../../schemas/profile');

module.exports = {
	data: new SlashCommandBuilder()
		.setName('addbal')
		.setDescription('Add balance to a user')
		.setDefaultMemberPermissions(PermissionFlagsBits.Administrator)

		.addUserOption(option =>
			option
				.setName('user')
				.setDescription('User to add balance to')
				.setRequired(true))

		.addNumberOption(option =>
			option
				.setName('amount')
				.setDescription('Amount to add')
				.setRequired(true)),

	async execute(interaction, client) {

		await interaction.deferReply({ ephemeral: true });

		const targetUser = interaction.options.getUser('user');
		let amount = interaction.options.getNumber('amount');

		amount = Number(amount.toFixed(2));

		if (amount <= 0) {
			return interaction.editReply({
				content: '❌ Amount must be greater than 0.'
			});
		}

		// Get profile
		let userProfile = await Profile.findOne({ userId: targetUser.id });

		if (!userProfile) {
			userProfile = await Profile.create({ userId: targetUser.id });
		}

		// Update balance
		await Profile.findOneAndUpdate(
			{ userId: targetUser.id },
			{
				$inc: {
					balance: amount,
					totalDeposited: amount
				}
			}
		);

		const embed = new EmbedBuilder()
			.setTitle('💰 Balance Added')
			.setColor(0x00ff00)
			.addFields(
				{
					name: '👤 User',
					value: `<@${targetUser.id}>`,
					inline: true
				},
				{
					name: '💵 Amount Added',
					value: `$${amount.toFixed(2)}`,
					inline: true
				},
				{
					name: '🛠 Added By',
					value: `<@${interaction.user.id}>`,
					inline: true
				}
			)
			.setTimestamp();

		await interaction.editReply({
			embeds: [embed]
		});

	}
};