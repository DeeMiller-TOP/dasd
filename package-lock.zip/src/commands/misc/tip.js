const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const profile = require('../../schemas/profile.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('tip')
        .setDescription('Tips another member balance')
        .addUserOption(option =>
            option
                .setName('target')
                .setDescription('A member in this guild')
                .setRequired(true))
        .addNumberOption(option =>
            option
                .setName('amount')
                .setDescription('The amount you would like to tip the target Ex: 10.2')
                .setRequired(true)),
    async execute(interaction, client) {
        await interaction.deferReply();

        // Gets the targets discord information
        const target = interaction.options.getUser('target');

        // Gets the sender's profile and the target's profile
        let interactorProfile = await client.getProfile(interaction.user.id);
        let targetProfile = await client.getProfile(target.id);

        // Gets the amount to tip
        let amount = interaction.options.getNumber('amount');
        amount = Number(amount.toFixed(2));

        // Validation checks
        if (interactorProfile.totalWagered < 0) {
            return interaction.editReply({
                embeds: [{
                    title: "🚫 Error",
                    description: `> <@${interaction.user.id}>, You have a wager requirement! You can't tip`,
                    color: 0xbe1932,
                    footer: { text: "Make sure you wager more" }
                }]
            });
        }

        if (interactorProfile.userId === targetProfile.userId) {
            return interaction.editReply({
                embeds: [{
                    title: "🚫 Error",
                    description: `> <@${interaction.user.id}>, you can't tip yourself!`,
                    color: 0xbe1932,
                    footer: { text: "Please mention a different member" }
                }]
            });
        }

        if (interactorProfile.activeGame) {
            return interaction.editReply({
                embeds: [{
                    title: "🚫 Error",
                    description: `> <@${interaction.user.id}>, you have an active game!`,
                    color: 0xbe1932,
                    footer: { text: "Please wait for that game to end" }
                }]
            });
        }

        if (interactorProfile.activeWithdraw) {
            return interaction.editReply({
                embeds: [{
                    title: "🚫 Error",
                    description: `> <@${interaction.user.id}>, you already have an active withdraw!`,
                    color: 0xbe1932,
                    footer: { text: "Please wait for that withdraw to finish" }
                }]
            });
        }

        if (amount < 0.01) {
            return interaction.editReply({
                embeds: [{
                    title: "🚫 Error",
                    description: `> <@${interaction.user.id}>, you can't tip less than $0.01!`,
                    color: 0xbe1932,
                    footer: { text: "Make sure that your tip amount is above $0.01" }
                }]
            });
        }

        if (interactorProfile.balance < amount) {
            return interaction.editReply({
                embeds: [{
                    title: "🚫 Error",
                    description: `> <@${interaction.user.id}>, you don't have enough balance to complete this tip!`,
                    color: 0xbe1932,
                    footer: { text: "Use the command /balance to check your balance" }
                }]
            });
        }

        // Takes away the balance from the sender
        await profile.findOneAndUpdate({ userId: interaction.user.id }, { $inc: { balance: -amount, totalTipped: +amount } });

        // Gives balance to the target
        await profile.findOneAndUpdate({ userId: target.id }, { $inc: { balance: +amount, totalTipsReceived: +amount } });

        // Reloads the profiles
        interactorProfile = await client.getProfile(interaction.user.id);
        targetProfile = await client.getProfile(target.id);

        // Builds the message embed
        const tipEmbed = new EmbedBuilder()
            .addFields({
                name: '💸 Tip Info:',
                value: `> <@${interaction.user.id}> has tipped **$${amount}** to <@${target.id}>\n> <@${interaction.user.id}> now has 💵 **$${interactorProfile.balance.toFixed(2)}**\n> <@${target.id}> now has 💵 **$${targetProfile.balance.toFixed(2)}**`
            })
            .setAuthor({
                name: `${interaction.user.tag}`,
                iconURL: `https://cdn.discordapp.com/avatars/${interaction.user.id}/${interaction.user.avatar}.jpeg`
            })
            .setColor('#0071e7');

        // Sends the tip information embed
        await interaction.editReply({
            embeds: [tipEmbed]
        });
    },
};