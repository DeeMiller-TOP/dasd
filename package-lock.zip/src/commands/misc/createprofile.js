const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const axios = require('axios');
const Profile = require('../../schemas/profile.js');

const CALLBACK_URL = "https://example.com/callback"; // replace with your real callback

module.exports = {
    data: new SlashCommandBuilder()
        .setName('createprofile')
        .setDescription('Creates your profile and generates BTC + LTC deposit addresses'),

    async execute(interaction) {

        await interaction.deferReply({ ephemeral: true });

        try {

            let userProfile = await Profile.findOne({ userId: interaction.user.id });

            if (userProfile) {
                return interaction.editReply({ content: "⚠️ You already have a profile!" });
            }

            // ================= BTC WALLET =================

            let btcWallet, btcTransferKey, btcAddress;

            try {

                const btcWalletRes = await axios.post(
                    "https://apirone.com/api/v2/wallets",
                    {
                        currency: "btc",
                        callback: {
                            url: CALLBACK_URL,
                            data: { userId: interaction.user.id }
                        },
                        fee: "normal",
                        "processing-fee-policy": "fixed"
                    }
                );

                btcWallet = btcWalletRes.data.wallet;
                btcTransferKey = btcWalletRes.data.transfer_key;

                console.log("✅ BTC wallet created:", btcWallet);

                const btcAddrRes = await axios.post(
                    `https://apirone.com/api/v2/wallets/${btcWallet}/addresses`,
                    {
                        "addr-type": "p2sh-p2wpkh",
                        callback: {
                            method: "POST",
                            url: CALLBACK_URL,
                            data: { userId: interaction.user.id }
                        }
                    }
                );

                btcAddress = btcAddrRes.data.address;

                console.log("✅ BTC address generated:", btcAddress);

            } catch (err) {

                console.error("❌ BTC error:", err.response?.data || err.message);

                return interaction.editReply({
                    content: "❌ Failed to create BTC wallet/address."
                });

            }


            // ================= LTC WALLET =================

            let ltcWallet, ltcTransferKey, ltcAddress;

            try {

                const ltcWalletRes = await axios.post(
                    "https://apirone.com/api/v2/wallets",
                    {
                        currency: "ltc",
                        callback: {
                            url: CALLBACK_URL,
                            data: { userId: interaction.user.id }
                        },
                        fee: "priority",
                        "processing-fee-policy": "fixed"
                    }
                );

                ltcWallet = ltcWalletRes.data.wallet;
                ltcTransferKey = ltcWalletRes.data.transfer_key;

                console.log("✅ LTC wallet created:", ltcWallet);

                const ltcAddrRes = await axios.post(
                    `https://apirone.com/api/v2/wallets/${ltcWallet}/addresses`,
                    {
                        "addr-type": "p2sh-p2wpkh",
                        callback: {
                            method: "POST",
                            url: CALLBACK_URL,
                            data: { userId: interaction.user.id }
                        }
                    }
                );

                ltcAddress = ltcAddrRes.data.address;

                console.log("✅ LTC address generated:", ltcAddress);

            } catch (err) {

                console.error("❌ LTC error:", err.response?.data || err.message);

                return interaction.editReply({
                    content: "❌ Failed to create LTC wallet/address."
                });

            }


            // ================= SAVE PROFILE =================

            userProfile = new Profile({

                userId: interaction.user.id,

                balance: 0,
                totalWagered: 0,
                activeGame: false,
                activeWithdraw: false,

                btcAddress: btcAddress,
                btcWallet: btcWallet,
                btcTransferKey: btcTransferKey,

                ltcAddress: ltcAddress,
                ltcWallet: ltcWallet,
                ltcTransferKey: ltcTransferKey

            });

            await userProfile.save();


            // ================= SUCCESS EMBED =================

            const embed = new EmbedBuilder()
                .setTitle("✅ Profile Created")
                .setColor("#00ff00")
                .setDescription(
`> <@${interaction.user.id}> your profile has been created.

**BTC Deposit Address**
\`${btcAddress}\`

**LTC Deposit Address**
\`${ltcAddress}\`
`
                );

            await interaction.editReply({ embeds: [embed] });

        } catch (err) {

            console.error("❌ Profile creation error:", err);

            if (!interaction.replied) {

                await interaction.editReply({
                    content: "❌ An unexpected error occurred."
                });

            }

        }

    }
};