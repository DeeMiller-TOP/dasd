const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('help')
        .setDescription('Shows all of the bots current commands'),
    async execute(interaction, client) {
        await interaction.deferReply();

        // Logs the user into the database if they aren't in it already
        await client.getProfile(interaction.user.id);

        // Builds the message embed
        const helpEmbed = new EmbedBuilder()
            .setAuthor({
                name: `${client.user.username}'s Commands`,
                iconURL: `https://cdn.discordapp.com/avatars/${client.user.id}/${client.user.avatar}.jpeg`
            })
            .addFields(
                {
                    name: `:coin: Crypto`,
                    value: `> **/deposit** \`{crypto}\`\n> **/withdraw** \`{crypto}\` \`{amount}\` \`{address}\`\n> **/prices**`
                },
                {
                    name: `🎰 PVP Games`,
                    value: `> **/flip** \`@user\` \`{amount}\`\n> **/duel** \`@user\` \`{amount}\``
                },
                {
                    name: `🎰 PVH Games`,
                    value: `> **/bj** \`{amount}\`\n> **/dice** \`{multiplier}\` \`{amount}\``
                },
                {
                    name: `📚 Information`,
                    value: `> **/help**\n> **/bjrules**\n> **/balance** \`@user\`\n> **/stats** \`@user\``
                },
                {
                    name: `👍 Provably Fair`,
                    value: `> **/bjinfo** \`{blackjack id}\`\n> **/dinfo** \`{dice id}\`\n> **/cfinfo** \`{coinflip id}\`\n> **/ddinfo** \`{dice duel id}\``
                },
                {
                    name: `💡 Misc`,
                    value: `> **/tip** \`@user\` \`{amount}\`\n> **/airdrop** \`{amount}\` \`{time}\`\n> **/giveaway** \`{amount}\` \`{time}\``
                }
            )
            .setFooter({
                text: 'To use any of these commands just type / in the text bar! | Minimum withdraw: $5, Maximum win: $20'
            })
            .setColor('#389cf4');

        // Sends the bots help command embed
        await interaction.editReply({
            embeds: [helpEmbed]
        });
    },
};