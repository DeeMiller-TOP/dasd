const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const coinflip = require('../../schemas/coinflip');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('cfinfo')
        .setDescription('Shows information on a coinflip id')
        .addStringOption(option =>
            option
                .setName('id')
                .setDescription('An id of a past coinflip')
                .setRequired(true)),
    async execute(interaction, client) {
        await interaction.deferReply();

        const id = interaction.options.getString('id');

        // Gets the coinflip
        const coinflipProfile = await client.getCoinflip(id);

        // Makes sure that there is actually a coinflip with that id
        if (!coinflipProfile) {
            return interaction.editReply({
                embeds: [{
                    title: "🚫 Error",
                    description: `> <@${interaction.user.id}>, there is no coinflip with the id of ${id}!`,
                    color: 0xbe1932,
                    footer: { text: "Make sure to use a valid id next time" }
                }]
            });
        }

        // Shows the result to the member
        let coinside;
        if (coinflipProfile.result == 1) {
            coinside = 'heads';
        } else {
            coinside = 'tails';
        }

        // Builds the message embed
        const informationEmbed = new EmbedBuilder()
            .setAuthor({
                name: `${client.user.username}'s Database`,
                iconURL: `https://cdn.discordapp.com/avatars/${client.user.id}/${client.user.avatar}.jpeg`
            })
            .setTitle(`:coin: Coinflip ID ${id}`)
            .setDescription(`> [Click here](https://api.random.org/signatures/form) to verify this data on [random.org](https://random.org/)`)
            .addFields(
                {
                    name: `🏆 Winner:`,
                    value: `<@${coinflipProfile.winnerId}>`,
                    inline: true
                },
                {
                    name: `💀 Loser:`,
                    value: `<@${coinflipProfile.loserId}>`,
                    inline: true
                },
                {
                    name: `💵 Total Amount Flipped:`,
                    value: `\`$${coinflipProfile.totalAmount}\``,
                    inline: true
                },
                {
                    name: `❓ Result:`,
                    value: `\`${coinflipProfile.result} - (${coinside})\``,
                    inline: true
                },
                {
                    name: `📅 Date/Time:`,
                    value: `\`${coinflipProfile.time}\``,
                    inline: true
                },
                {
                    name: `🖊️ Signature:`,
                    value: `\`${coinflipProfile.signature}\``,
                    inline: false
                },
                {
                    name: `🎲 Random:`,
                    value: `\`${coinflipProfile.random}\``,
                    inline: false
                }
            )
            .setFooter({ text: 'Click the link above and paste in the information to verify the result' })
            .setColor('#389cf4');

        // Sends information on the coinflip
        await interaction.editReply({
            embeds: [informationEmbed]
        });
    },
};