const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('balance')
        .setDescription('Shows your balance')
        .addUserOption(option =>
            option
                .setName('target')
                .setDescription('A member in this guild')),
    async execute(interaction, client) {
        await interaction.deferReply();

        // Checks to see if the user was getting someones balance or their own balance
        const user = interaction.options.getUser('target') || interaction.user;

        // Either gets or creates a profile and returns the data
        const userProfile = await client.getProfile(user.id);

        // Builds the message embed
        const balanceEmbed = new EmbedBuilder()
            .setAuthor({
                name: `${user.tag}`,
                iconURL: `https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.jpeg`
            })
            .addFields({
                name: 'Balance:',
                value: `💵 $${userProfile.balance.toFixed(2)}`,
                inline: false
            })
            .setColor('#389cf4');

        // Sends the members balance
        await interaction.editReply({
            embeds: [balanceEmbed]
        });
    },
};