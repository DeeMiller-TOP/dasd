// src/schemas/profile.js

const mongoose = require("mongoose");

const profileSchema = new mongoose.Schema(
{
    userId: {
        type: String,
        required: true,
        unique: true,
        index: true
    },

    // ================= BALANCE =================

    balance: {
        type: Number,
        default: 0
    },

    profit: {
        type: Number,
        default: 0
    },

    wins: {
        type: Number,
        default: 0
    },

    loses: {
        type: Number,
        default: 0
    },

    totalGamesPlayed: {
        type: Number,
        default: 0
    },

    totalWagered: {
        type: Number,
        default: 0
    },

    totalDeposited: {
        type: Number,
        default: 0
    },

    totalWithdrawed: {
        type: Number,
        default: 0
    },

    totalTipped: {
        type: Number,
        default: 0
    },

    totalTipsReceived: {
        type: Number,
        default: 0
    },

    // ================= STATUS =================

    activeGame: {
        type: Boolean,
        default: false
    },

    activeWithdraw: {
        type: Boolean,
        default: false
    },

    // ================= BTC =================

    btcAddress: {
        type: String,
        default: null
    },

    btcWallet: {
        type: String,
        default: null
    },

    btcTransferKey: {
        type: String,
        default: null
    },

    // ================= LTC =================

    ltcAddress: {
        type: String,
        default: null
    },

    ltcWallet: {
        type: String,
        default: null
    },

    ltcTransferKey: {
        type: String,
        default: null
    }

},
{
    timestamps: true
});

module.exports = mongoose.model("Profile", profileSchema);