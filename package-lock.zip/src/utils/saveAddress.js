const Profile = require("../schemas/profile");

async function saveBTCAddress(userId, address)
{
    try {

        const profile = await Profile.findOneAndUpdate(
            { userId: userId },
            { btcAddress: address },
            {
                upsert: true,
                new: true
            }
        );

        return profile;

    } catch (err) {
        console.error("Error saving BTC address:", err);
    }
}

module.exports = saveBTCAddress;