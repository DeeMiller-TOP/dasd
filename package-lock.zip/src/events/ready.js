module.exports = {
    name: "ready",
    once: true,
    execute(client) {
        console.log(`✅ Bot is Loaded and Ready! Logged in as ${client.user.tag}`);
        client.user.setActivity('/ Commands - /help', { type: 'WATCHING' });
    }
}