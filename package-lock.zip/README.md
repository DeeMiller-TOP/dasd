# Discord Casino Bot

A feature-rich Discord casino bot with provably fair games, crypto deposits/withdrawals, and more. Built with Discord.js v14 and MongoDB.

## Features

- 🎰 **Casino Games**
  - Coinflip (1v1 with 5% tax)
  - Dice (adjustable multiplier, 95% RTP)
  - Dice Duels (1v1 dice rolling)
  - Blackjack (multi-deck with standard rules)

- 💰 **Crypto Integration**
  - Deposit via Apirone (multi-cryptocurrency support)
  - Withdraw to external wallets
  - Real-time balance tracking

- 🎁 **Community Features**
  - Airdrops (distribute funds to multiple users)
  - Giveaways (random winner selection)
  - Tipping system

- 🔐 **Provably Fair Gaming**
  - Random.org API integration for verifiable randomness
  - Signed results with serial numbers for verification
  - Complete game history in database

- 📊 **User Profiles**
  - Balance tracking
  - Win/loss statistics
  - Total wagered tracking
  - Profit/loss calculation

## Prerequisites

- Node.js 18.x or higher
- MongoDB database
- Discord Bot Token
- Random.org API credentials
- Apirone account (for crypto payments)

## Installation

1. **Clone or download the repository**

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Configure environment variables**
   
   Copy `.env.example` to `.env` and fill in your credentials:
   ```env
   # Discord Configuration
   BOT_TOKEN=your_discord_bot_token
   CLIENT_ID=your_discord_application_id
   GUILD_ID=your_test_guild_id_optional

   # MongoDB Configuration
   MONGO_URI=mongodb://localhost:27017/casino_bot

   # Random.org Configuration
   API_KEY=your_random_org_api_key
   RND_USER=your_random_org_username
   RND_PASS=your_random_org_password

   # Apirone Configuration
   APIRONE_WALLET_ID=your_apirone_wallet_id
   APIRONE_TRANSFER_KEY=your_apirone_transfer_key
   ```

4. **Start the bot**
   ```bash
   npm start
   ```

## Commands

### Games

| Command | Description |
|---------|-------------|
| `/flip <amount> <target>` | Challenge another user to a coinflip |
| `/dice <multiplier> <amount>` | Roll dice with custom multiplier (1.02x - 1000x) |
| `/duel <target> <amount>` | Challenge another user to a dice duel |

### Blackjack

| Command | Description |
|---------|-------------|
| `/bj <amount>` | Start a blackjack game |
| `/bjrules` | View blackjack rules |
| `/bjinfo` | View blackjack game information |

### Crypto

| Command | Description |
|---------|-------------|
| `/deposit` | Generate a deposit address |
| `/withdraw <amount> <address>` | Withdraw funds to external wallet |

### Information

| Command | Description |
|---------|-------------|
| `/balance` | Check your current balance |
| `/stats` | View your gaming statistics |
| `/help` | Display all available commands |
| `/cfinfo` | View coinflip information |
| `/dinfo <serial>` | Verify dice game fairness |
| `/ddinfo <serial>` | Verify dice duel fairness |

### Misc

| Command | Description |
|---------|-------------|
| `/tip <target> <amount>` | Send money to another user |
| `/airdrop <amount> <time>` | Create an airdrop for multiple users |
| `/giveaway <amount> <time>` | Create a giveaway with random winner |

## Time Format

For airdrops and giveaways, use the following format:
- `10s` - 10 seconds
- `5m` - 5 minutes
- `2h` - 2 hours
- `1d` - 1 day

## Game Mechanics

### Coinflip
- 50/50 chance
- 5% tax on winnings
- Minimum bet: $0.02
- Provably fair via Random.org

### Dice
- 95% RTP (Return to Player)
- Customizable multiplier (1.02x - 1000x)
- Win chance = 95 / multiplier
- Minimum bet: $0.02

### Dice Duel
- Roll against another player
- Higher roll wins
- 5% tax on winnings
- Draw = no winner (funds returned)

### Blackjack
- Standard blackjack rules
- Dealer stands on 17
- Blackjack pays 3:2
- Insurance available when dealer shows Ace

## Database Schemas

### Profile Schema
```javascript
{
  userId: String,
  balance: Number,
  totalWagered: Number,
  wins: Number,
  loses: Number,
  profit: Number,
  totalGamesPlayed: Number,
  activeGame: Boolean,
  activeWithdraw: Boolean,
  totalAirdropped: Number,
  totalAirdroppedReceived: Number
}
```

## API Integrations

### Random.org
Used for provably fair random number generation. All game results are signed and verifiable.

### Apirone
Cryptocurrency payment processor for deposits and withdrawals. Supports multiple cryptocurrencies.

## Error Handling

The bot includes comprehensive error handling for:
- Insufficient balance
- Active games
- Active withdrawals
- Invalid input amounts
- Time parsing errors
- API failures

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Open a Pull Request

## License

MIT License - see LICENSE file for details

## Support

For support, please open an issue on the repository or contact the bot developer.

---

**Disclaimer**: This bot involves simulated gambling with cryptocurrency. Please ensure compliance with local laws and regulations regarding online gambling and cryptocurrency usage in your jurisdiction.