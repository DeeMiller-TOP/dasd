require('dotenv').config();

const fs = require('node:fs');
const path = require('node:path');
const axios = require('axios');

const { 
    Client, 
    Collection, 
    GatewayIntentBits, 
    REST, 
    Routes 
} = require('discord.js');

const mongoose = require('mongoose');

const Profile = require('./src/schemas/profile');


// ================= ENV VALIDATION =================

const REQUIRED_ENV = [
    "BOT_TOKEN",
    "GUILD_ID",
    "BTC_APIRONE_WALLET_ID",
    "LTC_APIRONE_WALLET_ID"
];

for (const env of REQUIRED_ENV) {
    if (!process.env[env]) {
        console.error(`❌ Missing environment variable: ${env}`);
        process.exit(1);
    }
}


// ================= MONGODB =================

const MONGO_URI = "mongodb+srv://rwbdallas_db_user:daddymiller112@cluster0.eokls0r.mongodb.net/";

(async () => {
    try {
        await mongoose.connect(MONGO_URI);
        console.log("✅ Connected to MongoDB");
    } catch (err) {
        console.error("❌ MongoDB connection error:", err);
    }
})();


// ================= DISCORD CLIENT =================

const CLIENT_ID = "1482863172917395537";
const GUILD_ID = process.env.GUILD_ID;

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.DirectMessages,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMembers
    ]
});

client.commands = new Collection();


// ================= COMMAND LOADER =================

function loadCommands(directory) {

    const files = fs.readdirSync(directory, { withFileTypes: true });

    for (const file of files) {

        const fullPath = path.join(directory, file.name);

        if (file.isDirectory()) {
            loadCommands(fullPath);
            continue;
        }

        if (!file.name.endsWith(".js")) continue;

        const command = require(fullPath);

        if (!command.data || !command.execute) {
            console.warn(`⚠️ ${file.name} missing data or execute`);
            continue;
        }

        client.commands.set(command.data.name, command);
    }
}

loadCommands(path.join(__dirname, "src", "commands"));

console.log(`✅ Loaded ${client.commands.size} commands`);


// ================= REGISTER SLASH COMMANDS =================

const rest = new REST({ version: "10" }).setToken(process.env.BOT_TOKEN);

(async () => {

    try {

        const commands = client.commands.map(cmd => cmd.data.toJSON());

        await rest.put(
            Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID),
            { body: commands }
        );

        console.log(`✅ Registered ${commands.length} slash commands`);

    } catch (err) {

        console.error("❌ Command registration error:", err);

    }

})();


// ================= PROFILE SYSTEM =================

client.getProfile = async function(userId) {

    let profile = await Profile.findOne({ userId });

    if (!profile) {
        profile = await Profile.create({ userId });
    }

    return profile;
};


// ================= ADDRESS SYSTEM =================

client.getAddress = async function(userId) {

    const profile = await client.getProfile(userId);

    if (profile.btcAddress && profile.ltcAddress) {
        return profile;
    }

    let btcAddress = profile.btcAddress;
    let ltcAddress = profile.ltcAddress;

    const requestData = {
        "addr-type": "p2sh-p2wpkh"
    };

    try {

        // ================= BTC ADDRESS =================

        if (!btcAddress) {

            console.log("⚡ Generating BTC Address");
            console.log("Wallet:", process.env.BTC_APIRONE_WALLET_ID);

            const btcRes = await axios.post(
                `https://apirone.com/api/v2/wallets/${process.env.BTC_APIRONE_WALLET_ID}/addresses`,
                requestData
            );

            btcAddress = btcRes.data.address;

            console.log("✅ BTC Address Generated:", btcAddress);
        }


        // ================= LTC ADDRESS =================

        if (!ltcAddress) {

            console.log("⚡ Generating LTC Address");
            console.log("Wallet:", process.env.LTC_APIRONE_WALLET_ID);

            const ltcRes = await axios.post(
                `https://apirone.com/api/v2/wallets/${process.env.LTC_APIRONE_WALLET_ID}/addresses`,
                requestData
            );

            ltcAddress = ltcRes.data.address;

            console.log("✅ LTC Address Generated:", ltcAddress);
        }


        profile.btcAddress = btcAddress;
        profile.ltcAddress = ltcAddress;

        await profile.save();

        return profile;

    } catch (err) {

        console.error("❌ Address generation error");

        if (err.response) {
            console.error("Status:", err.response.status);
            console.error("Response:", err.response.data);
        } else {
            console.error(err);
        }

        throw new Error("Failed to generate crypto address");
    }

};


// ================= COMMAND HANDLER =================

client.on("interactionCreate", async interaction => {

    if (!interaction.isChatInputCommand()) return;

    const command = client.commands.get(interaction.commandName);

    if (!command) return;

    try {

        await command.execute(interaction, client);

    } catch (err) {

        console.error("❌ Command execution error:", err);

        const reply = {
            content: "❌ There was an error executing this command.",
            ephemeral: true
        };

        if (interaction.replied || interaction.deferred) {
            await interaction.followUp(reply);
        } else {
            await interaction.reply(reply);
        }

    }

});


// ================= READY =================

client.once("ready", () => {

    console.log(`🚀 Logged in as ${client.user.tag}`);
    console.log(`📡 Bot is ready`);

});


// ================= LOGIN =================

client.login(process.env.BOT_TOKEN);


// ================= SAFETY =================

process.on("unhandledRejection", err => {
    console.error("Unhandled Promise Rejection:", err);
});

process.on("uncaughtException", err => {
    console.error("Uncaught Exception:", err);
});

process.on("SIGINT", () => {

    console.log("🛑 Shutting down bot...");

    client.destroy();

    process.exit(0);

});